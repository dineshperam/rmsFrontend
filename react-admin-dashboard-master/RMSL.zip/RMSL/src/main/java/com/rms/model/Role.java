package com.rms.model;

public enum Role {
	Artist,Admin,Manager

}
