package com.rms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rms.model.Transactions;
import com.rms.repository.TransactionRepository;

@Service
public class TransactionService {
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	public List<Transactions> showTrans(){
		return transactionRepository.findAll();
	}
	
	public List<Transactions> showTransByUserId(int id){
		return transactionRepository.findByUserId(id);
	}
	
	public List<Transactions> showTransByManId(int id){
		return transactionRepository.findByManagerId(id);
	}

}
