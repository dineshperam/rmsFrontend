package com.rms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rms.model.UserDetails;
import com.rms.repository.UserDetailsRepository;
import com.rms.service.UserDetailsService;
import com.rms.util.EncryptPassword;

@RestController
@RequestMapping(value = "/user")
@CrossOrigin(origins="*")
public class UserDetailsController {
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private UserDetailsRepository userDetailsRepository;
	
	UserDetails userDetails = new UserDetails();
	
	
	@PostMapping(value="/addUser")
	public void addUser(@RequestBody UserDetails userDetails) {
//		String encry = EncryptPassword.getCode(userDetails.getPasswordHash());
//		userDetails.setPasswordHash(encry);
		userDetailsService.addUser(userDetails);
	}
	
	@GetMapping(value = "/searchUser/{userid}")
	public ResponseEntity<UserDetails> searchUser(@PathVariable int userid){
		try {
			UserDetails userDetails=userDetailsService.searchUser(userid);
			return new ResponseEntity<UserDetails>(userDetails,HttpStatus.OK);
		}catch (NoSuchElementException e) {
			return new ResponseEntity<UserDetails>(HttpStatus.NOT_FOUND);		
		
	 }
		
	}
	
	@PutMapping(value = "/updateUser")
	 public void updateUser(@RequestBody UserDetails userDetails) {
		userDetailsService.updateUser(userDetails);
	}
	
	@DeleteMapping(value = "/deleteUser/{userid}")
	public void deleteUser(@PathVariable int userid) {
		userDetailsService.deleteUser(userid);
	}
	
	@GetMapping(value = "/showUser")
	public List<UserDetails>showUser(){
		return userDetailsService.showUsers();
		
	}
	
//	@GetMapping(value = "/login/{user}/{pass}")
//	public String login(@PathVariable String user, @PathVariable String pass) {
//	    UserDetails checkUser = userDetailsService.searchByUseName(user);
//	    if (checkUser != null) {
//	        String hashedPass = EncryptPassword.getCode(pass); 
//	        if (checkUser.getPasswordHash().equals(hashedPass)) {
//	            return "Login successful!"; 
//	        }
//	    }
//	    return "Incorrect credentials!";
//	}
//	

	@GetMapping(value = "/login/{user}/{pass}")
	public ResponseEntity<?	> login(@PathVariable String user, @PathVariable String pass) {
	    UserDetails checkUser = userDetailsService.searchByUseName(user);
	    if (checkUser != null) {
	      //  String hashedPass = EncryptPassword.getCode(pass); 
	        if (checkUser.getPassword().equals(pass)) {
	        	Map<String, Object> response = new HashMap<>();
	            response.put("user", checkUser);
	            return ResponseEntity.ok(response); 
	        }
	    }
	    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Incorrect credentials!");
	}
	
	@GetMapping(value = "/searchByUserName/{user}")
	public ResponseEntity<UserDetails> searchByUserName(@PathVariable String user){
		try {
			UserDetails userDetails=userDetailsService.searchByUseName(user);
			return new ResponseEntity<UserDetails>(userDetails,HttpStatus.OK);
		}catch (NoSuchElementException e) {
			return new ResponseEntity<UserDetails>(HttpStatus.NOT_FOUND);		
		
	 }
		
	}
	
	@GetMapping(value="/getArtists")
	public ResponseEntity<List<UserDetails>> getArtists(){
		try {
			List<UserDetails> userDetails = userDetailsService.findArtists();
			return new ResponseEntity<List<UserDetails>>(userDetails, HttpStatus.OK);
		}catch(NoSuchElementException e) {
			return new ResponseEntity<List<UserDetails>>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping(value="/getManagers")
	public ResponseEntity<List<UserDetails>> getManagers(){
		try {
			List<UserDetails> userDetails = userDetailsService.findManagers();
			return new ResponseEntity<List<UserDetails>>(userDetails, HttpStatus.OK);
		}catch(NoSuchElementException e) {
			return new ResponseEntity<List<UserDetails>>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping(value="/getAdmins")
	public ResponseEntity<List<UserDetails>> getAdmins(){
		try {
			List<UserDetails> userDetails = userDetailsService.findAdmins();
			return new ResponseEntity<List<UserDetails>>(userDetails, HttpStatus.OK);
		}catch(NoSuchElementException e) {
			return new ResponseEntity<List<UserDetails>>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping(value="/getArtistUnderManager/{id}")
	public ResponseEntity<List<UserDetails>> getArtistUnderManager(@PathVariable int id){
		try {
			List<UserDetails> userDetails = userDetailsService.findArtistsUnderManager(id);
			return new ResponseEntity<List<UserDetails>>(userDetails, HttpStatus.OK);
		}catch(NoSuchElementException e) {
			return new ResponseEntity<List<UserDetails>>(HttpStatus.NOT_FOUND);
		}
	}
	
	 @GetMapping("/current")
	    public ResponseEntity<UserDetails> getCurrentUser(){
	        return ResponseEntity.ok(userDetailsService.getCurrentLoggedInUser());
	    }
	
}
