package com.rms.service;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.rms.model.Royalty;
 
import com.rms.repository.RoyaltyRepository;
 
 
@Service
public class RoyaltyService {
	@Autowired
	private RoyaltyRepository royaltyRepository;
	public List<Royalty> showRoyalty(){
		return royaltyRepository.findAll();
	}
	public Royalty searchRoyaltyById(int royaltyId) {
		return royaltyRepository.findById(royaltyId).get();
	}
	public void addRoyalty(Royalty royalty) {
		royaltyRepository.save(royalty);
	}
	public void updateRoyalty(Royalty updatedRoyalty) {
		royaltyRepository.save(updatedRoyalty);
	}
	public void deleteRoyalty(int id) {
		royaltyRepository.deleteById(id);
	}
	public List<Royalty> searchByartistId(int artistId){
	     return royaltyRepository.findByArtistId(artistId);
	}
	public List<Royalty> searchBysongId(int songId){
	     return royaltyRepository.findBySongId(songId);
	}
    private double calculateRoyaltyAmount(int streams) {
        if (streams <= 10000) {
            return streams * 0.002;
        } else if (streams <= 50000) {
            return 10000 * 0.002 + (streams - 10000) * 0.005;
        } else {
            return 10000 * 0.002 + (50000 - 10000) * 0.005 + (streams - 50000) * 0.01;
        }
    }
}