package com.rms.model;
 
import java.util.Date;
 
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="royalties")
 
public class Royalty {
	@Id
	private int royaltyId;
	private int songId;
	private Date calculatedDate;
	private long totalStreams;
	private double royaltyAmount;
	private int artistId;
}