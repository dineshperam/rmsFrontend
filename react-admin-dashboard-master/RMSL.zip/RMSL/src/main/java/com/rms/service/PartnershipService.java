package com.rms.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rms.model.Partnership;
import com.rms.repository.PartnershipRepository;

@Service
public class PartnershipService {

    @Autowired
    private PartnershipRepository partnershipRepository;

    // Create a new Partnership
    public Partnership createPartnership(Partnership partnership) {
        return partnershipRepository.save(partnership);
    }

    // Get all Partnerships
    public List<Partnership> getAllPartnerships() {
        return partnershipRepository.findAll();
    }

    // Get a Partnership by ID
    public Partnership getPartnershipById(int id) {
        return partnershipRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Partnership not found with ID: " + id));
    }

    // Update an existing Partnership
    public Partnership updatePartnership(int id, Partnership partnership) {
        Partnership existing = getPartnershipById(id); // Use the method here
        existing.setArtistid(partnership.getArtistid());
        existing.setManagerid(partnership.getManagerid());
        existing.setStatus(partnership.getStatus());
        return partnershipRepository.save(existing);
    }
    // Delete a Partnership by ID
    public void deletePartnership(int id) {
        if (!partnershipRepository.existsById(id)) {
            throw new RuntimeException("Partnership not found with ID: " + id);
        }
        partnershipRepository.deleteById(id);
    }
}
