import React from 'react';
import "@testing-library/jest-dom";
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import ArtistRequests from './ArtistRequests';
import ApiService from '../../../service/ApiService';

// Mock the ApiService module
jest.mock('../../../service/ApiService');

describe('ArtistRequests Component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('renders list of managers when no existing manager', async () => {
    ApiService.getUserId.mockReturnValue('1');
    ApiService.getManagerId.mockReturnValue(null);
    const managersMock = [
      { username: 'Manager One', userid: 101 },
      { username: 'Manager Two', userid: 102 },
    ];
    ApiService.getManagers.mockResolvedValue(managersMock);

    render(<ArtistRequests />);

    await waitFor(() => {
      expect(screen.getByText('Manager One')).toBeInTheDocument();
      expect(screen.getByText('Manager Two')).toBeInTheDocument();
    });

    const partnerButtons = screen.getAllByText('Partner');
    expect(partnerButtons.length).toBe(2);
  });

  test('selects a manager and displays partnership request form', async () => {
    ApiService.getUserId.mockReturnValue('1');
    ApiService.getManagerId.mockReturnValue(null);
    const managersMock = [{ username: 'Manager One', userid: 101 }];
    ApiService.getManagers.mockResolvedValue(managersMock);

    render(<ArtistRequests />);

    await waitFor(() => {
      expect(screen.getByText('Manager One')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('Partner'));

    await waitFor(() => {
      expect(screen.getByText('Submit Partnership Request')).toBeInTheDocument();
    });
    // Instead of getByLabelText, verify the input by checking its default value ("10")
    expect(screen.getByDisplayValue('10')).toBeInTheDocument();
  });

  test('submits partnership request successfully', async () => {
    ApiService.getUserId.mockReturnValue('1');
    ApiService.getManagerId.mockReturnValue(null);
    const managersMock = [{ username: 'Manager One', userid: 101 }];
    ApiService.getManagers.mockResolvedValue(managersMock);
    ApiService.sendPartnershipRequest.mockResolvedValue({});

    render(<ArtistRequests />);

    await waitFor(() => {
      expect(screen.getByText('Manager One')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('Partner'));

    await waitFor(() => {
      expect(screen.getByText('Submit Partnership Request')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('Submit Request'));

    await waitFor(() => {
      expect(
        screen.getByText('Your request is under processing. We will get back to you.')
      ).toBeInTheDocument();
    });

    expect(ApiService.sendPartnershipRequest).toHaveBeenCalledWith(
      1,
      101,
      10,
      3,
      ""
    );
  });

  test('renders existing partnership details when manager exists', async () => {
    ApiService.getUserId.mockReturnValue('1');
    ApiService.getManagerId.mockReturnValue(101);
    const partnershipDetailsMock = {
      partnershipId: 123,
      managerId: 101,
      status: 'Active',
      percentage: 10,
      comments: 'Test comment',
      startDate: '2025-01-01',
      endDate: '2025-04-01',
      durationMonths: 3,
    };
    ApiService.getArtistPartnership.mockResolvedValue(partnershipDetailsMock);
    const managersMock = [
      { username: 'Manager One', userid: 101 },
      { username: 'Manager Two', userid: 102 },
    ];
    ApiService.getManagers.mockResolvedValue(managersMock);

    render(<ArtistRequests />);

    await waitFor(() => {
      expect(screen.getByText('Existing Partnership Details')).toBeInTheDocument();
    });
    expect(screen.getByText('123')).toBeInTheDocument();
    expect(screen.getByText('Active')).toBeInTheDocument();
    expect(screen.getByText('Export as PDF')).toBeInTheDocument();
  });

  test('calls export PDF on clicking export button', async () => {
    ApiService.getUserId.mockReturnValue('1');
    ApiService.getManagerId.mockReturnValue(101);
    const partnershipDetailsMock = {
      partnershipId: 123,
      managerId: 101,
      status: 'Active',
      percentage: 10,
      comments: 'Test comment',
      startDate: '2025-01-01',
      endDate: '2025-04-01',
      durationMonths: 3,
    };
    ApiService.getArtistPartnership.mockResolvedValue(partnershipDetailsMock);
    const managersMock = [{ username: 'Manager One', userid: 101 }];
    ApiService.getManagers.mockResolvedValue(managersMock);

    // Ensure createObjectURL exists
    if (!window.URL.createObjectURL) {
      window.URL.createObjectURL = jest.fn(() => 'blob:url');
    } else {
      jest.spyOn(window.URL, 'createObjectURL').mockReturnValue('blob:url');
    }

    const dummyBlob = new Blob(['dummy content'], { type: 'application/pdf' });
    ApiService.exportPartnershipPDF.mockResolvedValue(dummyBlob);

    render(<ArtistRequests />);

    await waitFor(() => {
      expect(screen.getByText('Export as PDF')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('Export as PDF'));

    await waitFor(() => {
      // Change expectation to use the string '1' since getUserId returns '1'
      expect(ApiService.exportPartnershipPDF).toHaveBeenCalledWith('1');
    });
  });
});
