import React from "react";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import ArtistsTransTable from "./ArtistsTransTable";
import ApiService from "../../../service/ApiService";

jest.mock("../../../service/ApiService");

describe("ArtistsTransTable", () => {
  const dummyTransactions = [
    {
      transactionId: "tx1",
      sender: "sender1",
      receiver: "receiver1",
      royaltyId: "royalty1",
      transactionDate: new Date("2022-01-01").toISOString(),
      transactionAmount: 100,
      managerId: "manager1",
      transactionType: "type1",
    },
    {
      transactionId: "tx2",
      sender: "sender2",
      receiver: "receiver2",
      royaltyId: "royalty2",
      transactionDate: new Date("2022-01-02").toISOString(),
      transactionAmount: 200,
      managerId: "manager2",
      transactionType: "type2",
    },
  ];

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("shows loading state initially", () => {
    // Simulate a promise that never resolves to remain in the loading state
    ApiService.fetchTransactionsById.mockReturnValue(new Promise(() => {}));
    render(<ArtistsTransTable />);
    // Query for the exact text with ellipsis
    expect(screen.getByText("Loading data...")).toBeInTheDocument();
  });

  test("renders transactions after successful fetch", async () => {
    ApiService.fetchTransactionsById.mockResolvedValue(dummyTransactions);
    render(<ArtistsTransTable />);
    
    // Wait for one transaction ID to appear in the document
    expect(await screen.findByText("tx1")).toBeInTheDocument();
    expect(screen.getByText("tx2")).toBeInTheDocument();
  });

  test("renders error message when fetch fails", async () => {
    ApiService.fetchTransactionsById.mockRejectedValue(new Error("Fetch error"));
    render(<ArtistsTransTable />);
    
    // Wait for the error message with exact text to appear
    expect(await screen.findByText("Error: Fetch error")).toBeInTheDocument();
  });

  test("paginates transactions correctly", async () => {
    // Create 12 dummy transactions (pageSize = 10)
    const manyTransactions = Array.from({ length: 12 }, (_, i) => ({
      transactionId: `tx${i + 1}`,
      sender: `sender${i + 1}`,
      receiver: `receiver${i + 1}`,
      royaltyId: `royalty${i + 1}`,
      transactionDate: new Date("2022-01-01").toISOString(),
      transactionAmount: 100 + i,
      managerId: `manager${i + 1}`,
      transactionType: `type${i + 1}`,
    }));
    ApiService.fetchTransactionsById.mockResolvedValue(manyTransactions);
    render(<ArtistsTransTable />);
    
    // Wait for the first transaction to appear
    await screen.findByText("tx1");
    
    // Expect that the first 10 transactions are rendered on page 1
    for (let i = 1; i <= 10; i++) {
      expect(screen.getByText(`tx${i}`)).toBeInTheDocument();
    }
    // Verify that transactions 11 and 12 are not visible on the first page
    expect(screen.queryByText("tx11")).not.toBeInTheDocument();
    expect(screen.queryByText("tx12")).not.toBeInTheDocument();
    
    // Click the Next Page button using its aria-label
    fireEvent.click(screen.getByLabelText("Next Page"));
    
    // Now, tx11 and tx12 should appear
    await waitFor(() => {
      expect(screen.getByText("tx11")).toBeInTheDocument();
      expect(screen.getByText("tx12")).toBeInTheDocument();
    });
  });

  test("handles export PDF functionality", async () => {
    ApiService.fetchTransactionsById.mockResolvedValue(dummyTransactions);
    ApiService.getUserId.mockReturnValue("user123");
    
    // Create a dummy blob to simulate a PDF file
    const dummyBlob = new Blob(["dummy content"], { type: "application/pdf" });
    ApiService.exportTransByUsersPDF.mockResolvedValue(dummyBlob);
    
    render(<ArtistsTransTable />);
    await screen.findByText("tx1");
    
    // Query for the Export PDF button by its exact text
    const exportButton = screen.getByText("Export PDF");
    fireEvent.click(exportButton);
    
    await waitFor(() => {
      expect(ApiService.exportTransByUsersPDF).toHaveBeenCalledWith("user123");
    });
  });

  test("sorts transactions by Transaction ID when header is clicked", async () => {
    // Start with unsorted transactions
    const unsortedTransactions = [
      {
        transactionId: "tx2",
        sender: "sender2",
        receiver: "receiver2",
        royaltyId: "royalty2",
        transactionDate: new Date("2022-01-02").toISOString(),
        transactionAmount: 200,
        managerId: "manager2",
        transactionType: "type2",
      },
      {
        transactionId: "tx1",
        sender: "sender1",
        receiver: "receiver1",
        royaltyId: "royalty1",
        transactionDate: new Date("2022-01-01").toISOString(),
        transactionAmount: 100,
        managerId: "manager1",
        transactionType: "type1",
      },
    ];
    ApiService.fetchTransactionsById.mockResolvedValue(unsortedTransactions);
    const { container } = render(<ArtistsTransTable />);
    await screen.findByText("tx2");
    
    // Find the header by its text then retrieve the closest button element
    const headerSpan = screen.getByText("Transaction ID");
    const headerButton = headerSpan.closest("button");
    expect(headerButton).toBeInTheDocument();
    
    // Click to sort ascending; expect tx1 to appear before tx2
    fireEvent.click(headerButton);
    let dataRows = container.querySelectorAll("tbody tr");
    expect(dataRows[0]).toHaveTextContent("tx1");
    expect(dataRows[1]).toHaveTextContent("tx2");
    
    // Click again to sort descending
    fireEvent.click(headerButton);
    dataRows = container.querySelectorAll("tbody tr");
    expect(dataRows[0]).toHaveTextContent("tx2");
    expect(dataRows[1]).toHaveTextContent("tx1");
  });
});