import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import Royalties from "./Royalties";
import ApiService from "../../../service/ApiService";
import { toast } from "react-toastify";

// Mock the ApiService module
jest.mock("../../../service/ApiService");

// Optionally, spy on toast methods
jest.spyOn(toast, "success").mockImplementation(() => {});
jest.spyOn(toast, "error").mockImplementation(() => {});

describe("Royalties Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("renders loading state initially and then displays royalties", async () => {
    const sampleRoyalties = [
      {
        royaltyId: 1,
        songId: 101,
        artistId: 201,
        totalStreams: 1000,
        royaltyAmount: 500.0,
        calculatedDate: new Date().toISOString(),
        status: "UNPAID",
      },
    ];
    ApiService.getRoyalties.mockResolvedValueOnce(sampleRoyalties);

    render(<Royalties />);

    // Initially, the loading text should appear
    expect(screen.getByText(/Loading royalties/i)).toBeInTheDocument();

    // Wait for the table data to appear after fetching royalties
    const royaltyIdCell = await screen.findByText("1");
    expect(royaltyIdCell).toBeInTheDocument();
    expect(screen.getByText("101")).toBeInTheDocument();
    expect(screen.getByText("201")).toBeInTheDocument();
    expect(screen.getByText("1000")).toBeInTheDocument();
    expect(screen.getByText("₹500.00")).toBeInTheDocument();
  });

  test("displays error message when fetching royalties fails", async () => {
    ApiService.getRoyalties.mockRejectedValueOnce(new Error("Network Error"));

    render(<Royalties />);

    const errorMessage = await screen.findByText(/Failed to fetch royalties/i);
    expect(errorMessage).toBeInTheDocument();
  });

  test("handles calculate royalties button click", async () => {
    // Initially return an empty array
    ApiService.getRoyalties.mockResolvedValueOnce([]);
    ApiService.calculateRoyalties.mockResolvedValueOnce({});

    render(<Royalties />);

    // Click the "Calculate Royalties" button
    const calcButton = screen.getByText(/Calculate Royalties/i);
    fireEvent.click(calcButton);

    // Ensure calculateRoyalties is called
    await waitFor(() => {
      expect(ApiService.calculateRoyalties).toHaveBeenCalled();
    });

    // After calculating, fetchRoyalties is called again
    await waitFor(() => {
      expect(ApiService.getRoyalties).toHaveBeenCalledTimes(2);
    });

    // Verify toast notification was called
    expect(toast.success).toHaveBeenCalledWith(
      "Royalties calculated successfully!",
      expect.objectContaining({ position: "top-right", autoClose: 2000 })
    );
  });

  test("handles successful payment for a royalty", async () => {
    const royalty = {
      royaltyId: 1,
      songId: 101,
      artistId: 201,
      totalStreams: 1000,
      royaltyAmount: 500.0,
      calculatedDate: new Date().toISOString(),
      status: "UNPAID",
    };

    ApiService.getRoyalties.mockResolvedValueOnce([royalty]);
    ApiService.getUserId.mockReturnValue("admin123");
    ApiService.payRoyalty.mockResolvedValueOnce({});

    // Mock window.confirm to always return true
    window.confirm = jest.fn().mockReturnValue(true);

    render(<Royalties />);

    // Wait for the Pay button to appear and click it
    const payButton = await screen.findByText(/Pay/i);
    fireEvent.click(payButton);

    // Ensure the payRoyalty method is called with correct arguments
    await waitFor(() => {
      expect(ApiService.payRoyalty).toHaveBeenCalledWith(royalty.royaltyId, "admin123");
    });

    // Check that a success toast is shown
    expect(toast.success).toHaveBeenCalledWith(
      `Royalty of ₹${royalty.royaltyAmount} paid successfully!`,
      expect.objectContaining({ position: "top-right", autoClose: 2000 })
    );

    // Verify that the status changes to PAID in the UI
    await waitFor(() => {
      expect(screen.getByText(/PAID/)).toBeInTheDocument();
    });
  });

  test("handles payment failure", async () => {
    const royalty = {
      royaltyId: 2,
      songId: 102,
      artistId: 202,
      totalStreams: 2000,
      royaltyAmount: 1000.0,
      calculatedDate: new Date().toISOString(),
      status: "UNPAID",
    };

    ApiService.getRoyalties.mockResolvedValueOnce([royalty]);
    ApiService.getUserId.mockReturnValue("admin123");
    ApiService.payRoyalty.mockResolvedValueOnce({ error: "Payment error" });

    // Mock window.confirm to return true
    window.confirm = jest.fn().mockReturnValue(true);

    render(<Royalties />);

    const payButton = await screen.findByText(/Pay/i);
    fireEvent.click(payButton);

    // Ensure the payRoyalty method was called
    await waitFor(() => {
      expect(ApiService.payRoyalty).toHaveBeenCalledWith(royalty.royaltyId, "admin123");
    });

    // Verify that an error toast is shown on payment failure
    expect(toast.error).toHaveBeenCalledWith(
      `Payment failed: Payment error`,
      expect.objectContaining({ position: "top-right", autoClose: 3000 })
    );
  });
});
