// AllTransactions.test.jsx
import React from "react";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import AllTransactions from "./AllTransactionsTable";
import "@testing-library/jest-dom";
import ApiService from "../../../service/ApiService";
import userEvent from "@testing-library/user-event";

// Mock the ApiService so we can control its responses
jest.mock("../../../service/ApiService");

const sampleTransactions = [
  {
    transactionId: "1",
    sender: "Alice",
    receiver: "Bob",
    royaltyId: "roy1",
    transactionDate: new Date("2022-01-01T00:00:00Z").toISOString(),
    transactionAmount: 100,
    managerId: "mgr1",
  },
  {
    transactionId: "2",
    sender: "Charlie",
    receiver: "Dave",
    royaltyId: "roy2",
    transactionDate: new Date("2022-01-02T00:00:00Z").toISOString(),
    transactionAmount: 200,
    managerId: "mgr2",
  },
];

describe("AllTransactions Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("displays a loading indicator initially", async () => {
    // Return a pending promise so loading remains visible
    ApiService.fetchTransactions.mockReturnValue(new Promise(() => {}));
    render(<AllTransactions />);
    expect(screen.getByText(/Loading data.../i)).toBeInTheDocument();
  });

  test("displays transactions after data is loaded", async () => {
    ApiService.fetchTransactions.mockResolvedValue(sampleTransactions);
    render(<AllTransactions />);

    // Wait for the header to be rendered (data loaded)
    await waitFor(() => {
      expect(screen.getByText("All Transactions")).toBeInTheDocument();
    });

    // Instead of checking for "1", check for a unique value like "Alice"
    expect(screen.getByText("Alice")).toBeInTheDocument();
    expect(screen.getByText("Bob")).toBeInTheDocument();
    expect(screen.getByText("roy1")).toBeInTheDocument();
    expect(screen.getByText(/₹100.00/)).toBeInTheDocument();
  });

  test("displays error message when fetch fails", async () => {
    ApiService.fetchTransactions.mockRejectedValue(new Error("Test error"));
    render(<AllTransactions />);

    await waitFor(() => {
      expect(screen.getByText(/Error:/i)).toBeInTheDocument();
    });
    expect(screen.getByText(/Test error/i)).toBeInTheDocument();
  });

  test("filters transactions based on search input", async () => {
    ApiService.fetchTransactions.mockResolvedValue(sampleTransactions);
    render(<AllTransactions />);

    await waitFor(() => {
      expect(screen.getByText("All Transactions")).toBeInTheDocument();
    });

    // Find the search input for Transaction ID
    const transactionSearchInput = screen.getByPlaceholderText("Search Transaction ID...");
    // Type a search term that does not match any transaction
    fireEvent.change(transactionSearchInput, { target: { value: "non-existent" } });

    // Expect that the transactions no longer appear in the table
    await waitFor(() => {
      expect(screen.queryByText("Alice")).not.toBeInTheDocument();
      expect(screen.queryByText("Charlie")).not.toBeInTheDocument();
    });
  });

  test("sorts transactions when clicking on a column header", async () => {
    // Create transactions in unsorted order
    const unsortedTransactions = [
      {
        transactionId: "2",
        sender: "Charlie",
        receiver: "Dave",
        royaltyId: "roy2",
        transactionDate: new Date("2022-01-02T00:00:00Z").toISOString(),
        transactionAmount: 200,
        managerId: "mgr2",
      },
      {
        transactionId: "1",
        sender: "Alice",
        receiver: "Bob",
        royaltyId: "roy1",
        transactionDate: new Date("2022-01-01T00:00:00Z").toISOString(),
        transactionAmount: 100,
        managerId: "mgr1",
      },
    ];
    ApiService.fetchTransactions.mockResolvedValue(unsortedTransactions);
    render(<AllTransactions />);

    await waitFor(() => {
      expect(screen.getByText("All Transactions")).toBeInTheDocument();
    });

    // Check initial order by ensuring the first row contains transactionId "2"
    const rowsBeforeSort = screen.getAllByRole("row");
    // rowsBeforeSort[0] is the header; rowsBeforeSort[1] is the first data row
    expect(rowsBeforeSort[1]).toHaveTextContent("2");

    // Click the "Transaction ID" header to trigger sorting
    const header = screen.getByText("Transaction ID");
    fireEvent.click(header);

    // After sorting, the first data row should display transactionId "1"
    const rowsAfterSort = screen.getAllByRole("row");
    expect(rowsAfterSort[1]).toHaveTextContent("1");
  });

  test("handles pagination correctly", async () => {
    // Create 10 sample transactions (pageSize is 7)
    const manyTransactions = Array.from({ length: 10 }, (_, i) => {
      const day = (i % 30) + 1;
      // Pad day with a leading zero if necessary
      const dayStr = day < 10 ? `0${day}` : day.toString();
      return {
        transactionId: `${i + 1}`,
        sender: `Sender${i + 1}`,
        receiver: `Receiver${i + 1}`,
        royaltyId: `roy${i + 1}`,
        transactionDate: new Date(`2022-01-${dayStr}T00:00:00Z`).toISOString(),
        transactionAmount: 100 + i * 10,
        managerId: `mgr${i + 1}`,
      };
    });
    ApiService.fetchTransactions.mockResolvedValue(manyTransactions);
    render(<AllTransactions />);

    await waitFor(() => {
      expect(screen.getByText("All Transactions")).toBeInTheDocument();
    });

    // Expect 7 data rows on the first page (plus one header row)
    const firstPageRows = screen.getAllByRole("row");
    expect(firstPageRows.length).toBe(8);

    // Click on the page 2 button
    const page2Button = screen.getByRole("button", { name: "2" });
    fireEvent.click(page2Button);

    // Now expect only 3 data rows on page 2 (header plus 3 rows)
    const rowsPage2 = screen.getAllByRole("row");
    expect(rowsPage2.length).toBe(4);
  });

  test("exports PDF when export button is clicked", async () => {
    ApiService.fetchTransactions.mockResolvedValue(sampleTransactions);
    ApiService.exportTransPDF.mockResolvedValue("PDF data");

    // Mock URL.createObjectURL so we can track its use
    const createObjectURLMock = jest.fn(() => "blob:url");
    global.URL.createObjectURL = createObjectURLMock;

    render(<AllTransactions />);
    await waitFor(() => {
      expect(screen.getByText("All Transactions")).toBeInTheDocument();
    });

    const exportButton = screen.getByRole("button", { name: /Export PDF/i });
    fireEvent.click(exportButton);

    // Check that the button shows an exporting state
    expect(screen.getByText(/Exporting.../i)).toBeInTheDocument();

    await waitFor(() => {
      expect(ApiService.exportTransPDF).toHaveBeenCalled();
    });
  });
});
